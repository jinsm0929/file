package com.example.movielog.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity
@Getter @Setter
public class Review {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // 한 명의 회원은 여러 개의 리뷰를 쓸 수 있음
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id")
    private Member member;

    // 하나의 콘텐츠에는 여러 개의 리뷰가 달릴 수 있음
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "content_id")
    private Content content;

    private int rating; // 별점 (1~5점)

    @Column(nullable = false)
    private String comment; // 한줄평

    private LocalDateTime createdAt;

    @PrePersist // DB에 저장되기 직전 실행 (현재 시간 저장)
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
    }
}