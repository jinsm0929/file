package com.example.movielog.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class Member {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String nickname;

    // === 이 부분 추가! ===
    // 일반 회원은 "USER", 관리자는 "ADMIN" 이라는 값을 가집니다.
    @Column(nullable = false)
    private String role = "USER"; 
}