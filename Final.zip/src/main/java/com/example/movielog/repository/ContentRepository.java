package com.example.movielog.repository;

import com.example.movielog.domain.Content;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContentRepository extends JpaRepository<Content, Long> {
    // JpaRepository를 상속받으면 findAll(), findById() 등을 자동으로 사용할 수 있습니다.
}