package com.example.movielog.repository;

import com.example.movielog.domain.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface MemberRepository extends JpaRepository<Member, Long> {
    
    // 로그인 시 아이디(username)로 회원 정보를 조회하기 위한 커스텀 메서드
    Optional<Member> findByUsername(String username);
    
}