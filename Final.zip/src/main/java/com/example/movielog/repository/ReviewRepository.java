package com.example.movielog.repository;

import com.example.movielog.domain.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    // 특정 영화(contentId)에 달린 모든 리뷰를 가져오는 메서드
    List<Review> findByContentId(Long contentId);
}