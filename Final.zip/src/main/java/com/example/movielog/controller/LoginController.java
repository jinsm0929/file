package com.example.movielog.controller;

import com.example.movielog.domain.Member;
import com.example.movielog.repository.MemberRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final MemberRepository memberRepository;

    // 1. 로그인 화면 띄우기
    @GetMapping("/login")
    public String loginForm() {
        return "login"; // templates/login.html 화면으로 이동
    }

    // 2. 실제 로그인 검사 및 처리 (★이 부분이 수정된 핵심 로직입니다★)
    @PostMapping("/login")
    public String login(@RequestParam("username") String username,
                        @RequestParam("password") String password,
                        HttpServletRequest request) {
        
        // 데이터베이스에서 사용자가 입력한 아이디(username)를 찾음
        Optional<Member> findMember = memberRepository.findByUsername(username);
        
        // 아이디가 존재하고, 비밀번호도 일치한다면 로그인 성공!
        if (findMember.isPresent() && findMember.get().getPassword().equals(password)) {
            
            Member loginMember = findMember.get(); 
            
            // 세션에 로그인한 회원 정보를 저장
            HttpSession session = request.getSession();
            session.setAttribute("loginMember", loginMember);
            
            // ====================================================
            // [권한 분기 처리] 
            // 로그인한 사람의 역할(Role)이 'ADMIN'이면 관리자 페이지로,
            // 아니면 그냥 메인 페이지('/')로 보냅니다.
            // ====================================================
            if ("ADMIN".equals(loginMember.getRole())) {
                return "redirect:/admin"; 
            } else {
                return "redirect:/"; 
            }
        }
        
        // 로그인 실패 시 다시 로그인 화면으로 돌려보내고 에러 표시
        return "redirect:/login?error=true";
    }

    // 3. 로그아웃 처리
    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // 세션에 저장된 정보 파기
        }
        return "redirect:/"; // 로그아웃 후 메인 화면으로 이동
    }
}