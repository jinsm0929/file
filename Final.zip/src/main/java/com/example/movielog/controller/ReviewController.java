package com.example.movielog.controller;

import com.example.movielog.domain.Content;
import com.example.movielog.domain.Member;
import com.example.movielog.repository.ContentRepository;
import com.example.movielog.service.ReviewService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;
    private final ContentRepository contentRepository;

    @PostMapping("/review/add")
    public String addReview(@RequestParam("contentId") Long contentId,
                            @RequestParam("rating") int rating,
                            @RequestParam("comment") String comment,
                            HttpServletRequest request) {
        
        // 1. 세션에서 현재 로그인한 유저 정보 가져오기
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginMember") == null) {
            return "redirect:/login"; // 로그인 안 되어 있으면 로그인 페이지로 보냄
        }
        Member loginMember = (Member) session.getAttribute("loginMember");

        // 2. 어떤 영화에 다는 리뷰인지 영화 정보 가져오기
        Content content = contentRepository.findById(contentId)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 영화입니다."));

        // 3. 리뷰 저장 서비스 호출
        reviewService.saveReview(loginMember, content, rating, comment);

        // 4. 리뷰를 작성했던 그 영화의 상세 페이지로 다시 새로고침 이동
        return "redirect:/content/" + contentId;
    }
}