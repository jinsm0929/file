package com.example.movielog.controller;

import com.example.movielog.domain.Content;
import com.example.movielog.domain.Review;
import com.example.movielog.repository.ContentRepository;
import com.example.movielog.repository.ReviewRepository;
import com.example.movielog.service.ReviewService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class ContentController {

    private final ContentRepository contentRepository;
    private final ReviewRepository reviewRepository;
    private final ReviewService reviewService;

    // 영화 상세 페이지 조회 요청 처리
    @GetMapping("/content/{id}")
    public String detail(@PathVariable("id") Long id, Model model) {
        // 1. 영화 정보 가져오기
        Content content = contentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 콘텐츠가 없습니다. id=" + id));
        
        // 2. 해당 영화에 달린 리뷰 목록 가져오기
        List<Review> reviews = reviewRepository.findByContentId(id);
        
        // 3. 해당 영화의 평균 평점 계산하기
        double avgRating = reviewService.getAverageRating(id);

        // 4. HTML 화면(Thymeleaf)으로 데이터 전달하기
        model.addAttribute("content", content);
        model.addAttribute("reviews", reviews);
        model.addAttribute("avgRating", avgRating);

        return "content/detail"; // src/main/resources/templates/content/detail.html 파일로 이동
    }
}