package com.example.movielog.controller;

import com.example.movielog.domain.Member;
import com.example.movielog.repository.MemberRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.util.List;

@Controller
@RequiredArgsConstructor
public class AdminController {

    private final MemberRepository memberRepository;

    @GetMapping("/admin")
    public String adminPage(HttpServletRequest request, Model model) {
        // 1. 관리자인지 검증하는 로직 (보안)
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("loginMember") == null) {
            return "redirect:/login"; // 로그인 안 했으면 쫓아냄
        }
        
        Member loginMember = (Member) session.getAttribute("loginMember");
        if (!"ADMIN".equals(loginMember.getRole())) {
            return "redirect:/"; // 일반 유저가 주소창에 치고 들어오면 메인으로 쫓아냄
        }

        // 2. 관리자 페이지에 띄워줄 데이터 (예: 전체 회원 목록)
        List<Member> allMembers = memberRepository.findAll();
        model.addAttribute("members", allMembers);

        return "admin/dashboard"; // templates/admin/dashboard.html
    }
}