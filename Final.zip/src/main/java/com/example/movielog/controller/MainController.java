package com.example.movielog.controller;

import com.example.movielog.domain.Content;
import com.example.movielog.repository.ContentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class MainController {

    private final ContentRepository contentRepository;

    @GetMapping("/")
    public String mainPage(Model model) {
        // 1. DB에서 모든 콘텐츠(영화) 목록을 가져옴
        List<Content> contents = contentRepository.findAll();
        
        // 2. HTML(Thymeleaf)로 영화 목록 데이터를 전달
        model.addAttribute("contents", contents);
        
        // 3. src/main/resources/templates/main.html 화면을 띄움
        return "main"; 
    }
}