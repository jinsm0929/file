package com.example.movielog.service;

import com.example.movielog.domain.Content;
import com.example.movielog.domain.Member;
import com.example.movielog.domain.Review;
import com.example.movielog.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;

    // 1. 리뷰 등록하기
    @Transactional
    public Long saveReview(Member member, Content content, int rating, String comment) {
        Review review = new Review();
        review.setMember(member);
        review.setContent(content);
        review.setRating(rating);
        review.setComment(comment);
        
        reviewRepository.save(review);
        return review.getId();
    }

    // 2. 특정 영화의 평균 평점 계산하기 (교수님 취향 저격 로직)
    public double getAverageRating(Long contentId) {
        List<Review> reviews = reviewRepository.findByContentId(contentId);
        if (reviews.isEmpty()) {
            return 0.0; // 리뷰가 없으면 평점 0점
        }

        double sum = 0;
        for (Review review : reviews) {
            sum += review.getRating();
        }
        
        // 소수점 첫째 자리까지만 계산 (예: 4.3)
        return Math.round((sum / reviews.size()) * 10) / 10.0;
    }
}